1. /src/main/java/com/chinaweal/sdcs/crcs/system/service/ITUsersService.java
2. /src/main/java/com/chinaweal/sdcs/crcs/common/service/functions/CustomFilterFunction.java
3. /src/main/java/com/chinaweal/sdcs/crcs/analyse/scheduled/HowWordScheduled.java
4. /src/main/resources/mybatis/mapper/system/RightsProcessingLogMapper.xml
5. /src/main/java/com/chinaweal/sdcs/crcs/service/BaseServiceImpl.java
6. /src/main/resources/mybatis/mapper/system/RightsTransformRequestMapper.xml
7. /src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/RightsTransformRequestServiceImpl.java
8. /src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/impl/AppliancesVOServiceImpl.java
9. /src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/TOrgunitsServiceImpl.java
10. /src/main/java/com/chinaweal/sdcs/crcs/system/entity/Rights.java
11. /src/main/java/com/chinaweal/sdcs/crcs/system/service/RightsTransformRequestService.java
12. /src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/RightsServiceImpl.java
13. /src/main/java/com/chinaweal/sdcs/crcs/entity/dto/login/LoginMessage.java
14. /src/main/java/com/chinaweal/sdcs/crcs/system/mapper/RightsDetailsMapper.java
15. /src/main/java/com/chinaweal/sdcs/crcs/system/entity/RightsProcessingLog.java
16. /src/main/java/com/chinaweal/sdcs/crcs/system/entity/RightsDetails.java
17. /pom.xml
18. /src/main/java/com/chinaweal/sdcs/crcs/business/controller/ProcessinfoController.java
19. /src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/entity/MapChangeVO.java
20. /src/main/java/com/chinaweal/sdcs/crcs/common/service
21. /src/main/java/com/chinaweal/sdcs/crcs/business/entity/UsersApp.java
22. /src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/ExportComprehensiveImpl.java
23. /src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/impl/EachTypeVOServiceImpl.java
24. /src/main/java/com/chinaweal/sdcs/crcs/common/service/BaseService.java
25. /src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/impl/DataMapOneServiceImpl.java
26. /src/main/resources/mybatis/mapper/system/RightsMapper.xml
27. /src/main/java/com/chinaweal/sdcs/crcs/service/functions/CustomFilterFunction.java
28. /src/main/java/com/chinaweal/sdcs/crcs/system/entity/RightsTransformRequest.java
29. /src/main/java/com/chinaweal/sdcs/crcs/business/mapper/UsersAppMapper.java
30. /src/main/java/com/chinaweal/sdcs/crcs/util/StringUtils.java
31. /src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/impl/GeneralServiceImpl.java
32. /src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/IEachTypeVOService.java
33. /src/main/resources/mybatis/mapper/bigScreenDisplay/RegionOrderVOMapper.xml
34. /src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/UsersAppServiceImpl.java
35. /src/main/java/com/chinaweal/sdcs/crcs/system/service/ITOrgunitsService.java
36. /src/main/java/com/chinaweal/sdcs/crcs/common/controller
37. /src/main/resources/word/12315economyword.docx
38. /src/main/java/com/chinaweal/sdcs/crcs/common/service/functions/CustomWrapperPackingFunction.java
39. /src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/TasklistServiceImpl.java
40. /src/main/java/com/chinaweal/sdcs/crcs/controller
41. /src/main/java/com/chinaweal/sdcs/crcs/business/service/ITasklistService.java
42. /src/main/resources/mybatis/mapper/system/RightsDetailsMapper.xml
43. /src/main/java/com/chinaweal/sdcs/crcs/dev/MybatisPlusGenerator.java
44. /src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/entity/RegionOrderVO.java
45. /src/main/java/com/chinaweal/sdcs/crcs/system/service/IRightsService.java
46. /src/main/java/com/chinaweal/sdcs/crcs/statistical/common/controller/LeaderIndexCountListController.java
47. /src/main/java/com/chinaweal/sdcs/crcs/service/functions
48. /src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/RightsProcessingLogServiceImpl.java
49. /src/main/java/com/chinaweal/sdcs/crcs/system/controller/TOrgunitsController.java
50. /src/main/resources/word/complaintform.docx
51. /src/main/resources/mybatis/mapper/system/TOrgunitsMapper.xml
52. /src/main/java/com/chinaweal/sdcs/crcs/common/entity/dto/page/PageRequestDto.java
53. /src/main/java/com/chinaweal/sdcs/crcs/entity
54. /src/main/resources/mybatis/mapper/system/TUsersMapper.xml
55. /src/main/java/com/chinaweal/sdcs/crcs/system/controller/TUsersController.java
56. /src/main/java/com/chinaweal/sdcs/crcs/system/service/RightsProcessingLogService.java
57. /src/main/java/com/chinaweal/sdcs/crcs/service/functions/CustomWrapperPackingFunction.java
58. /src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/controller/ScreenDisplayController.java
59. /src/main/resources/mybatis/mapper/business/UserAppMapper.xml
60. /src/main/java/com/chinaweal/sdcs/crcs/system/service/IRightsDetailsService.java
61. /src/main/java/com/chinaweal/sdcs/crcs/system/mapper/TOrgunitsMapper.java
62. /src/main/java/com/chinaweal/sdcs/crcs/business/mapper/TasklistMapper.java
63. /src/main/java/com/chinaweal/sdcs/crcs/service/BaseService.java
64. /src/test/java/com/chinaweal/test/ExportRights.java
65. /src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/impl/BrandVOServiceImpl.java
66. /src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/ProcessinfoServiceImpl.java
67. /src/main/java/com/chinaweal/sdcs/crcs/entity/dto/page/PageRequestDto.java
68. /src/main/java/com/chinaweal/sdcs/crcs/system/mapper/RightsMapper.java
69. /src/main/java/com/chinaweal/sdcs/crcs/business/entity/Tasklist.java
70. /src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/mapper/DataMapOneMapper.java
71. /src/main/java/com/chinaweal/sdcs/crcs/service
72. /src/main/resources/mybatis/mapper/bigScreenDisplay/ScreenDisplayMapper.xml
73. /src/main/resources/mybatis/mapper/business/TasklistMapper.xml
74. /src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/IDataMapOneService.java
75. /src/main/java/com/chinaweal/sdcs/crcs/system/mapper/TUsersMapper.java
76. /src/main/resources/mybatis/mapper/system/IUsersAppSerivce.xml
77. /src/main/java/com/chinaweal/sdcs/crcs/util/BaseDataUtil.java
78. /src/main/java/com/chinaweal/sdcs/crcs/business/entity/Message.java
79. /src/main/java/com/chinaweal/sdcs/crcs/common/entity
80. /src/main/java/com/chinaweal/sdcs/crcs/common/controller/BaseController.java
81. /src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/RightsDetailsServiceImpl.java
82. /src/main/java/com/chinaweal/sdcs/crcs/system/entity/TUsers.java
83. /src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/impl/DataMapServiceImpl.java
84. /src/main/java/com/chinaweal/sdcs/crcs/controller/BaseController.java
85. /src/main/java/com/chinaweal/sdcs/crcs/business/controller/BusinessSearchController.java
86. /src/main/java/com/chinaweal/sdcs/crcs/common/entity/dto/login/LoginMessage.java
87. /src/main/java/com/chinaweal/sdcs/crcs/system/controller/RightsController.java
88. /src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/IDataMapService.java
89. /src/main/java/com/chinaweal/sdcs/crcs/entity/dto/login
90. /src/main/java/com/chinaweal/sdcs/crcs/common/service/functions
91. /src/main/resources/word/12315complaintword.docx
92. /src/main/java/com/chinaweal/sdcs/crcs/entity/dto
93. /src/main/java/com/chinaweal/sdcs/crcs/common/entity/dto/page
94. /src/main/java/com/chinaweal/sdcs/crcs/common
95. /src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/TUsersServiceImpl.java
96. /src/main/java/com/chinaweal/sdcs/crcs/common/service/BaseServiceImpl.java
97. /src/main/java/com/chinaweal/sdcs/crcs/entity/dto/page
98. /src/main/java/com/chinaweal/sdcs/crcs/common/entity/dto/login
99. /src/main/resources/mybatis/mapper/bigScreenDisplay/DataMapOneMapper.xml
100. /src/main/java/com/chinaweal/sdcs/crcs/common/entity/dto
101. /src/main/java/com/chinaweal/sdcs/crcs/system/mapper/RightsProcessingLogMapper.java
102. /src/main/java/com/chinaweal/sdcs/crcs/system/controller/RightsdetailsController.java
103. /src/main/java/com/chinaweal/sdcs/crcs/system/mapper/RightsTransformRequestMapper.java

---------------------------------------------
SVN HISTORIC INFO FROM 2210 TO 2368
---------------------------------------------
revision: 2210
author: liny
date: 2020-05-12 10:08:20
commit message: �����������ݽӿ�--˳�µ�ͼ����
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/IDataMapService.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/entity/MapChangeVO.java (from /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/entity/MapVO.java revision 2207)
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/impl/DataMapServiceImpl.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/controller/ScreenDisplayController.java

---------------------------------------------
revision: 2222
author: liny
date: 2020-05-13 17:02:31
commit message: ��������--���õ�����Ͷ��Ʒ��TOP10���ݽӿ�
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/controller/BusinessSearchController.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/impl/AppliancesVOServiceImpl.java

---------------------------------------------
revision: 2224
author: liny
date: 2020-05-13 20:28:47
commit message: ��������---�漰����TOP10���ݽӿ�
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/bigScreenDisplay/ScreenDisplayMapper.xml

---------------------------------------------
revision: 2236
author: liny
date: 2020-05-18 16:00:18
commit message: 1.����չʾ�������ݲ�ѯ�ӿ�-�ٱ���������������
2.����Ͷ��Ʒ��Top10��������
3.����������Ͷ��ҵ�������ݲ�ѯ�ӿ�
4.tasklistȱʧ�����������SQL����ʱ��
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/impl/DataMapOneServiceImpl.java
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/bigScreenDisplay/DataMapOneMapper.xml
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/bigScreenDisplay/RegionOrderVOMapper.xml
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/analyse/scheduled/HowWordScheduled.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/impl/BrandVOServiceImpl.java
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/business/TasklistMapper.xml
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/IDataMapOneService.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/controller/ScreenDisplayController.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/mapper/DataMapOneMapper.java

---------------------------------------------
revision: 2237
author: liny
date: 2020-05-18 18:15:26
commit message: �����������ݵ�ͼ��γ��

changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/impl/DataMapServiceImpl.java

---------------------------------------------
revision: 2238
author: liny
date: 2020-05-18 18:31:57
commit message: ������ͼ��γ��
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/impl/DataMapServiceImpl.java

---------------------------------------------
revision: 2240
author: mosx
date: 2020-05-18 20:06:00
commit message: ��������ǼǶ���ģ�顣���������Ǽǵ���ʱ�䣬���ű�����ϵͳ��Դ�ֶΣ���������ȥ�ء�
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/UsersAppServiceImpl.java
 NEW /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/system/IUsersAppSerivce.xml
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/ITOrgunitsService.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/mapper/TOrgunitsMapper.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/ITUsersService.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/TUsersController.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/mapper/TUsersMapper.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/entity/TUsers.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/ProcessinfoServiceImpl.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/TUsersServiceImpl.java
 NEW /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/system/TUsersMapper.xml
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/entity/Message.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/TOrgunitsController.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/mapper/UsersAppMapper.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/entity/UsersApp.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/TOrgunitsServiceImpl.java

---------------------------------------------
revision: 2241
author: liny
date: 2020-05-18 22:12:47
commit message: �����������ݲ�ѯ�ӿ�--��һ���µ�ҵ����(ҵ������)
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/impl/EachTypeVOServiceImpl.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/IEachTypeVOService.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/controller/ScreenDisplayController.java

---------------------------------------------
revision: 2244
author: mosx
date: 2020-05-19 11:11:30
commit message: �����ǼǶ��ű�ǵ���
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/system/TOrgunitsMapper.xml

---------------------------------------------
revision: 2245
author: mosx
date: 2020-05-19 12:40:19
commit message: ȱʧxml
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/business/UserAppMapper.xml

---------------------------------------------
revision: 2246
author: mosx
date: 2020-05-19 14:09:24
commit message: �޸������ǼǾٱ�����ѯ�޷����ɲ�������
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/ProcessinfoServiceImpl.java

---------------------------------------------
revision: 2247
author: liny
date: 2020-05-19 15:52:27
commit message: 1.�������ڰ췴������������opinion����
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/controller/ProcessinfoController.java

---------------------------------------------
revision: 2251
author: liny
date: 2020-05-19 20:02:46
commit message: �����������ݽӿ�--������Ͷ��ҵ����
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/entity/RegionOrderVO.java
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/bigScreenDisplay/RegionOrderVOMapper.xml

---------------------------------------------
revision: 2252
author: liny
date: 2020-05-19 20:11:22
commit message: ������������Ϊ��������
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/bigScreenDisplay/service/impl/GeneralServiceImpl.java

---------------------------------------------
revision: 2254
author: mosx
date: 2020-05-19 20:30:02
commit message: �޸������Ǽ�Ͷ�ߵ�word����ʧ������
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/resources/word/complaintform.docx
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/ExportComprehensiveImpl.java

---------------------------------------------
revision: 2261
author: mosx
date: 2020-05-20 10:05:00
commit message: �޸�12315Ͷ�ߺ;ٱ�����ʧ������
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/resources/word/12315economyword.docx
 MODIFY /SDCS/trunk/crcs/src/main/resources/word/12315complaintword.docx
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/ExportComprehensiveImpl.java

---------------------------------------------
revision: 2273
author: mosx
date: 2020-05-21 14:33:43
commit message: �ر�ԭ�ж��ŷ��ͷ�ʽ������SMS����Ȩ�޽ӿڣ��޸�����ʱ���ʽ��������
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/mapper/TOrgunitsMapper.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/ProcessinfoServiceImpl.java
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/system/TOrgunitsMapper.xml
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/TOrgunitsController.java

---------------------------------------------
revision: 2275
author: liny
date: 2020-05-21 16:03:25
commit message: 1.����ֹ�¼��--������������
2.tasklist�����ֶ�����
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/controller/ProcessinfoController.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/entity/Tasklist.java
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/business/TasklistMapper.xml
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/ProcessinfoServiceImpl.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/util/BaseDataUtil.java

---------------------------------------------
revision: 2284
author: mosx
date: 2020-05-22 17:45:58
commit message: �ӿ������������Ǽ�Ԥ���ж��ֶ�
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/mapper/TasklistMapper.java
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/business/TasklistMapper.xml
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/TasklistServiceImpl.java

---------------------------------------------
revision: 2286
author: mosx
date: 2020-05-22 17:54:11
commit message: ���Žӿ������쳣��׽�Լ�ResultCode��
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/TOrgunitsController.java

---------------------------------------------
revision: 2287
author: lirh
date: 2020-05-24 20:19:32
commit message: ע��ͣ��12315����12345
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/ProcessinfoServiceImpl.java

---------------------------------------------
revision: 2293
author: mosx
date: 2020-05-25 19:56:45
commit message: �������������õ���ʱ�䡣
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/controller/ProcessinfoController.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/ProcessinfoServiceImpl.java

---------------------------------------------
revision: 2304
author: mosx
date: 2020-05-26 12:09:44
commit message: ��������24Сʱ��Ԥ��������48Сʱ��Ԥ��
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/mapper/TasklistMapper.java
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/business/TasklistMapper.xml
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/TasklistServiceImpl.java

---------------------------------------------
revision: 2311
author: mosx
date: 2020-05-27 10:03:09
commit message: �����Ǽ����ڹ���
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/ProcessinfoServiceImpl.java

---------------------------------------------
revision: 2314
author: liny
date: 2020-05-27 11:33:09
commit message: ����άȨ����վ����Ϣ��ѯ�ӿڼ��ȹ��ļ�
changed paths:
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/RightsController.java (from /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/LoglistController.java revision 2297)
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/mapper/RightsMapper.java (from /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/mapper/LoglistMapper.java revision 2297)
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/entity/Rights.java (from /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/entity/Loglist.java revision 2297)
 NEW /SDCS/trunk/crcs/src/test/java/com/chinaweal/test/ExportRights.java (from /SDCS/trunk/crcs/src/test/java/com/chinaweal/test/ExportBusinessDataTestFour.java revision 2297)
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/IRightsService.java (from /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/ILoglistService.java revision 2297)
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/RightsServiceImpl.java (from /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/LoglistServiceImpl.java revision 2297)
 NEW /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/system/RightsMapper.xml (from /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/system/LoglistMapper.xml revision 2297)

---------------------------------------------
revision: 2318
author: mosx
date: 2020-05-28 10:55:53
commit message: �޸������Ǽ�������ʶ����ʧ�����⡣���������Ǽ��������ڹ���
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/ProcessinfoServiceImpl.java

---------------------------------------------
revision: 2319
author: mosx
date: 2020-05-28 14:23:19
commit message: �޸�����Ԥ����������ź�ϵͳ��Դʧ������
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/UsersAppServiceImpl.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/TOrgunitsController.java

---------------------------------------------
revision: 2321
author: liny
date: 2020-05-28 15:25:22
commit message: 1.����άȨ����չ�����ʵ�弰����ļ�
2.���άȨ��������洢�ӿ�
changed paths:
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/IRightsDetailsService.java (from /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/IRightsService.java revision 2316)
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/RightsdetailsController.java (from /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/RightsController.java revision 2316)
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/entity/RightsDetails.java (from /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/entity/Rights.java revision 2316)
 NEW /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/system/RightsDetailsMapper.xml (from /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/system/RightsMapper.xml revision 2316)
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/mapper/RightsDetailsMapper.java (from /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/mapper/RightsMapper.java revision 2316)
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/RightsDetailsServiceImpl.java (from /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/RightsServiceImpl.java revision 2316)
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/RightsServiceImpl.java

---------------------------------------------
revision: 2335
author: liny
date: 2020-05-29 17:25:44
commit message: 1.����άȨ�������������
2.����άȨ������洢�ӿڣ����ӹ����ź��û���ʶ
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/RightsdetailsController.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/entity/RightsDetails.java
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/system/RightsDetailsMapper.xml

---------------------------------------------
revision: 2337
author: lirh
date: 2020-06-01 14:57:55
commit message: άȨ��Ϣ��ҳ������ӿ�
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/IRightsDetailsService.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/RightsdetailsController.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/entity/RightsDetails.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/RightsDetailsServiceImpl.java

---------------------------------------------
revision: 2338
author: lirh
date: 2020-06-01 15:00:37
commit message: άȨ��Ϣ��ҳ������ӿ�
changed paths:
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/entity/dto/page
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/entity/dto/page/PageRequestDto.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/entity
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/entity/dto
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/service/functions
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/service/functions/CustomFilterFunction.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/service/functions/CustomWrapperPackingFunction.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/service/BaseServiceImpl.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/service

---------------------------------------------
revision: 2339
author: lirh
date: 2020-06-01 15:00:46
commit message: άȨ��Ϣ��ҳ������ӿ�
changed paths:
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/service/BaseService.java

---------------------------------------------
revision: 2340
author: lirh
date: 2020-06-01 15:21:05
commit message: ��ҳ�ӿڴ���ʱ�䷶Χ
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/RightsdetailsController.java

---------------------------------------------
revision: 2342
author: mosx
date: 2020-06-01 16:22:52
commit message: �����Ǽ��Ѱ�Ԥ�����ѽӿ�
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/ITasklistService.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/mapper/TasklistMapper.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/statistical/common/controller/LeaderIndexCountListController.java
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/business/TasklistMapper.xml
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/business/service/impl/TasklistServiceImpl.java

---------------------------------------------
revision: 2345
author: lirh
date: 2020-06-01 17:19:13
commit message: ��ҳ����
changed paths:
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/controller
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/RightsdetailsController.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/entity/dto/login
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/util/StringUtils.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/controller/BaseController.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/entity/dto/login/LoginMessage.java

---------------------------------------------
revision: 2347
author: mosx
date: 2020-06-01 19:48:39
commit message: �޸��û��ظ����¶��ŷ���ʧ��bug
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/business/UserAppMapper.xml
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/TOrgunitsController.java

---------------------------------------------
revision: 2348
author: liny
date: 2020-06-01 20:28:06
commit message: ����άȨ���񹤵������ɸ�ʽ
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/RightsdetailsController.java

---------------------------------------------
revision: 2349
author: mosx
date: 2020-06-01 20:41:36
commit message: ע�Ͷ��Žӿ�
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/TOrgunitsController.java

---------------------------------------------
revision: 2360
author: lirh
date: 2020-06-02 17:23:56
commit message: ����άȨ��������άȨ��ת���ӿڣ����Ӹ�ȫ�Ĵ���������
changed paths:
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/common/entity
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/mapper/RightsTransformRequestMapper.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/RightsProcessingLogService.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/common/service/BaseService.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/common/service/BaseServiceImpl.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/RightsdetailsController.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/entity/RightsTransformRequest.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/common/service/functions
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/common/service/functions/CustomFilterFunction.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/common/service/functions/CustomWrapperPackingFunction.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/RightsTransformRequestService.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/dev/MybatisPlusGenerator.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/entity/RightsProcessingLog.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/common/entity/dto/login
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/mapper/RightsProcessingLogMapper.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/RightsDetailsServiceImpl.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/common/controller/BaseController.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/common/entity/dto/login/LoginMessage.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/common/entity/dto/page
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/common/entity/dto
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/common/entity/dto/page/PageRequestDto.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/IRightsDetailsService.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/RightsTransformRequestServiceImpl.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/common
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/util/StringUtils.java
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/common/service
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/common/controller
 NEW /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/RightsProcessingLogServiceImpl.java

---------------------------------------------
revision: 2361
author: lirh
date: 2020-06-02 17:24:23
commit message: ����άȨ��������άȨ��ת���ӿڣ����Ӹ�ȫ�Ĵ���������
changed paths:
 MODIFY /SDCS/trunk/crcs/pom.xml
 NEW /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/system/RightsTransformRequestMapper.xml
 NEW /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/system/RightsProcessingLogMapper.xml

---------------------------------------------
revision: 2363
author: lirh
date: 2020-06-02 17:30:41
commit message: ɾ�������BaseController
changed paths:
 DELETE /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/controller

---------------------------------------------
revision: 2364
author: mosx
date: 2020-06-02 18:02:13
commit message: �Ѱ��ѯxml����feedback�ֶ�
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/business/TasklistMapper.xml

---------------------------------------------
revision: 2368
author: lirh
date: 2020-06-03 10:42:47
commit message: ���ֶμ��룬�����䷽�������д
changed paths:
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/mapper/RightsTransformRequestMapper.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/impl/RightsTransformRequestServiceImpl.java
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/system/RightsTransformRequestMapper.xml
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/controller/RightsdetailsController.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/entity/RightsDetails.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/service/RightsTransformRequestService.java
 MODIFY /SDCS/trunk/crcs/src/main/resources/mybatis/mapper/system/RightsDetailsMapper.xml
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/dev/MybatisPlusGenerator.java
 MODIFY /SDCS/trunk/crcs/src/main/java/com/chinaweal/sdcs/crcs/system/entity/RightsProcessingLog.java

